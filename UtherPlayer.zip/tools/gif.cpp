#include "gif.h"

Gif_H::Gif_H()
{

}

Gif_H::~Gif_H()
{

}
