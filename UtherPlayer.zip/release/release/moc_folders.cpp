/****************************************************************************
** Meta object code from reading C++ file 'folders.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../util/folders.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'folders.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Folders_t {
    QByteArrayData data[52];
    char stringdata0[764];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Folders_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Folders_t qt_meta_stringdata_Folders = {
    {
QT_MOC_LITERAL(0, 0, 7), // "Folders"
QT_MOC_LITERAL(1, 8, 21), // "makeIndex2FolderEmpty"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 25), // "makeFolderName2IndexEmpty"
QT_MOC_LITERAL(4, 57, 16), // "makePChosenEmpty"
QT_MOC_LITERAL(5, 74, 9), // "makeEmpty"
QT_MOC_LITERAL(6, 84, 13), // "hasFolderName"
QT_MOC_LITERAL(7, 98, 12), // "addNewFolder"
QT_MOC_LITERAL(8, 111, 11), // "_folderName"
QT_MOC_LITERAL(9, 123, 14), // "getFolderNames"
QT_MOC_LITERAL(10, 138, 9), // "getFolder"
QT_MOC_LITERAL(11, 148, 12), // "removeFolder"
QT_MOC_LITERAL(12, 161, 12), // "renameFolder"
QT_MOC_LITERAL(13, 174, 6), // "_index"
QT_MOC_LITERAL(14, 181, 14), // "_newFolderName"
QT_MOC_LITERAL(15, 196, 17), // "addContent2Folder"
QT_MOC_LITERAL(16, 214, 9), // "_fileName"
QT_MOC_LITERAL(17, 224, 9), // "_filePath"
QT_MOC_LITERAL(18, 234, 8), // "_isLocal"
QT_MOC_LITERAL(19, 243, 11), // "getUserName"
QT_MOC_LITERAL(20, 255, 11), // "setUserName"
QT_MOC_LITERAL(21, 267, 5), // "value"
QT_MOC_LITERAL(22, 273, 9), // "startInit"
QT_MOC_LITERAL(23, 283, 10), // "startClose"
QT_MOC_LITERAL(24, 294, 23), // "removeContentFromFolder"
QT_MOC_LITERAL(25, 318, 12), // "_folderIndex"
QT_MOC_LITERAL(26, 331, 13), // "_contentIndex"
QT_MOC_LITERAL(27, 345, 17), // "moveFolderContent"
QT_MOC_LITERAL(28, 363, 21), // "_toFolderContentIndex"
QT_MOC_LITERAL(29, 385, 23), // "_fromFolderContentIndex"
QT_MOC_LITERAL(30, 409, 10), // "moveFolder"
QT_MOC_LITERAL(31, 420, 14), // "_toFolderIndex"
QT_MOC_LITERAL(32, 435, 16), // "_fromFolderIndex"
QT_MOC_LITERAL(33, 452, 13), // "FolderContent"
QT_MOC_LITERAL(34, 466, 14), // "_folderContent"
QT_MOC_LITERAL(35, 481, 10), // "getPChosen"
QT_MOC_LITERAL(36, 492, 10), // "setPChosen"
QT_MOC_LITERAL(37, 503, 9), // "hasChosen"
QT_MOC_LITERAL(38, 513, 15), // "moveChosen2Next"
QT_MOC_LITERAL(39, 529, 15), // "moveChosen2Last"
QT_MOC_LITERAL(40, 545, 23), // "getPointedFolderContent"
QT_MOC_LITERAL(41, 569, 22), // "getPointedMediaContent"
QT_MOC_LITERAL(42, 592, 14), // "QMediaContent*"
QT_MOC_LITERAL(43, 607, 16), // "getPointedFolder"
QT_MOC_LITERAL(44, 624, 26), // "getNextRankOfPointedFolder"
QT_MOC_LITERAL(45, 651, 9), // "PlayOrder"
QT_MOC_LITERAL(46, 661, 9), // "playOrder"
QT_MOC_LITERAL(47, 671, 32), // "addChosenFolderContent2Histories"
QT_MOC_LITERAL(48, 704, 10), // "Histories&"
QT_MOC_LITERAL(49, 715, 10), // "_histories"
QT_MOC_LITERAL(50, 726, 18), // "getFolderFilePaths"
QT_MOC_LITERAL(51, 745, 18) // "QList<QStringList>"

    },
    "Folders\0makeIndex2FolderEmpty\0\0"
    "makeFolderName2IndexEmpty\0makePChosenEmpty\0"
    "makeEmpty\0hasFolderName\0addNewFolder\0"
    "_folderName\0getFolderNames\0getFolder\0"
    "removeFolder\0renameFolder\0_index\0"
    "_newFolderName\0addContent2Folder\0"
    "_fileName\0_filePath\0_isLocal\0getUserName\0"
    "setUserName\0value\0startInit\0startClose\0"
    "removeContentFromFolder\0_folderIndex\0"
    "_contentIndex\0moveFolderContent\0"
    "_toFolderContentIndex\0_fromFolderContentIndex\0"
    "moveFolder\0_toFolderIndex\0_fromFolderIndex\0"
    "FolderContent\0_folderContent\0getPChosen\0"
    "setPChosen\0hasChosen\0moveChosen2Next\0"
    "moveChosen2Last\0getPointedFolderContent\0"
    "getPointedMediaContent\0QMediaContent*\0"
    "getPointedFolder\0getNextRankOfPointedFolder\0"
    "PlayOrder\0playOrder\0"
    "addChosenFolderContent2Histories\0"
    "Histories&\0_histories\0getFolderFilePaths\0"
    "QList<QStringList>"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Folders[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  174,    2, 0x0a /* Public */,
       3,    0,  175,    2, 0x0a /* Public */,
       4,    0,  176,    2, 0x0a /* Public */,
       5,    0,  177,    2, 0x0a /* Public */,
       6,    1,  178,    2, 0x0a /* Public */,
       7,    1,  181,    2, 0x0a /* Public */,
       9,    0,  184,    2, 0x0a /* Public */,
      10,    1,  185,    2, 0x0a /* Public */,
      10,    1,  188,    2, 0x0a /* Public */,
      11,    1,  191,    2, 0x0a /* Public */,
      12,    2,  194,    2, 0x0a /* Public */,
      15,    4,  199,    2, 0x0a /* Public */,
      15,    4,  208,    2, 0x0a /* Public */,
      19,    0,  217,    2, 0x0a /* Public */,
      20,    1,  218,    2, 0x0a /* Public */,
      22,    0,  221,    2, 0x0a /* Public */,
      23,    0,  222,    2, 0x0a /* Public */,
      24,    2,  223,    2, 0x0a /* Public */,
      27,    3,  228,    2, 0x0a /* Public */,
      30,    2,  235,    2, 0x0a /* Public */,
      15,    2,  240,    2, 0x0a /* Public */,
      35,    0,  245,    2, 0x0a /* Public */,
      36,    1,  246,    2, 0x0a /* Public */,
      37,    0,  249,    2, 0x0a /* Public */,
      38,    0,  250,    2, 0x0a /* Public */,
      39,    0,  251,    2, 0x0a /* Public */,
      40,    0,  252,    2, 0x0a /* Public */,
      41,    0,  253,    2, 0x0a /* Public */,
      43,    0,  254,    2, 0x0a /* Public */,
      44,    1,  255,    2, 0x0a /* Public */,
      47,    1,  258,    2, 0x0a /* Public */,
      50,    0,  261,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::QStringList,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,   13,   14,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::Bool,   13,   16,   17,   18,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    8,   16,   17,   18,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   25,   26,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int,   25,   28,   29,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   31,   32,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 33,    8,   34,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 42,
    QMetaType::Void,
    QMetaType::Int, 0x80000000 | 45,   46,
    QMetaType::Void, 0x80000000 | 48,   49,
    0x80000000 | 51,

       0        // eod
};

void Folders::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Folders *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->makeIndex2FolderEmpty(); break;
        case 1: _t->makeFolderName2IndexEmpty(); break;
        case 2: _t->makePChosenEmpty(); break;
        case 3: _t->makeEmpty(); break;
        case 4: { bool _r = _t->hasFolderName((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: _t->addNewFolder((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: { QStringList _r = _t->getFolderNames();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 7: _t->getFolder((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 8: _t->getFolder((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 9: _t->removeFolder((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 10: _t->renameFolder((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 11: _t->addContent2Folder((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const bool(*)>(_a[4]))); break;
        case 12: _t->addContent2Folder((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const bool(*)>(_a[4]))); break;
        case 13: { QString _r = _t->getUserName();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 14: _t->setUserName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->startInit(); break;
        case 16: _t->startClose(); break;
        case 17: _t->removeContentFromFolder((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 18: _t->moveFolderContent((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 19: _t->moveFolder((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 20: _t->addContent2Folder((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const FolderContent(*)>(_a[2]))); break;
        case 21: { int _r = _t->getPChosen();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 22: _t->setPChosen((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: { bool _r = _t->hasChosen();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 24: _t->moveChosen2Next(); break;
        case 25: _t->moveChosen2Last(); break;
        case 26: _t->getPointedFolderContent(); break;
        case 27: { QMediaContent* _r = _t->getPointedMediaContent();
            if (_a[0]) *reinterpret_cast< QMediaContent**>(_a[0]) = std::move(_r); }  break;
        case 28: _t->getPointedFolder(); break;
        case 29: { int _r = _t->getNextRankOfPointedFolder((*reinterpret_cast< const PlayOrder(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 30: _t->addChosenFolderContent2Histories((*reinterpret_cast< Histories(*)>(_a[1]))); break;
        case 31: { QList<QStringList> _r = _t->getFolderFilePaths();
            if (_a[0]) *reinterpret_cast< QList<QStringList>*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Folders::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Folders.data,
    qt_meta_data_Folders,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Folders::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Folders::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Folders.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Folders::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
