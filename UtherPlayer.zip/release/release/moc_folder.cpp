/****************************************************************************
** Meta object code from reading C++ file 'folder.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../util/folder.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'folder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Folder_t {
    QByteArrayData data[38];
    char stringdata0[517];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Folder_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Folder_t qt_meta_stringdata_Folder = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Folder"
QT_MOC_LITERAL(1, 7, 16), // "getFolderContent"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 11), // "getFileName"
QT_MOC_LITERAL(4, 37, 12), // "getFileNames"
QT_MOC_LITERAL(5, 50, 14), // "QList<QString>"
QT_MOC_LITERAL(6, 65, 18), // "makeContainerEmpty"
QT_MOC_LITERAL(7, 84, 18), // "makeFileNamesEmpty"
QT_MOC_LITERAL(8, 103, 16), // "makePChosenEmpty"
QT_MOC_LITERAL(9, 120, 9), // "makeEmpty"
QT_MOC_LITERAL(10, 130, 7), // "hasFile"
QT_MOC_LITERAL(11, 138, 20), // "addAndSetRankContent"
QT_MOC_LITERAL(12, 159, 14), // "FolderContent&"
QT_MOC_LITERAL(13, 174, 13), // "removeContent"
QT_MOC_LITERAL(14, 188, 13), // "getFolderName"
QT_MOC_LITERAL(15, 202, 13), // "setFolderName"
QT_MOC_LITERAL(16, 216, 5), // "value"
QT_MOC_LITERAL(17, 222, 12), // "getContainer"
QT_MOC_LITERAL(18, 235, 24), // "QMap<int,FolderContent>*"
QT_MOC_LITERAL(19, 260, 11), // "moveContent"
QT_MOC_LITERAL(20, 272, 8), // "_toIndex"
QT_MOC_LITERAL(21, 281, 10), // "_fromIndex"
QT_MOC_LITERAL(22, 292, 11), // "updateRanks"
QT_MOC_LITERAL(23, 304, 7), // "getRank"
QT_MOC_LITERAL(24, 312, 7), // "setRank"
QT_MOC_LITERAL(25, 320, 17), // "getFolderContents"
QT_MOC_LITERAL(26, 338, 20), // "QList<FolderContent>"
QT_MOC_LITERAL(27, 359, 10), // "getPChosen"
QT_MOC_LITERAL(28, 370, 10), // "setPChosen"
QT_MOC_LITERAL(29, 381, 9), // "hasChosen"
QT_MOC_LITERAL(30, 391, 15), // "moveChosen2Next"
QT_MOC_LITERAL(31, 407, 15), // "moveChosen2Last"
QT_MOC_LITERAL(32, 423, 17), // "getPointedContent"
QT_MOC_LITERAL(33, 441, 13), // "isEmptyFolder"
QT_MOC_LITERAL(34, 455, 22), // "getNextRankByPlayOrder"
QT_MOC_LITERAL(35, 478, 9), // "PlayOrder"
QT_MOC_LITERAL(36, 488, 9), // "playOrder"
QT_MOC_LITERAL(37, 498, 18) // "getRankedFilePaths"

    },
    "Folder\0getFolderContent\0\0getFileName\0"
    "getFileNames\0QList<QString>\0"
    "makeContainerEmpty\0makeFileNamesEmpty\0"
    "makePChosenEmpty\0makeEmpty\0hasFile\0"
    "addAndSetRankContent\0FolderContent&\0"
    "removeContent\0getFolderName\0setFolderName\0"
    "value\0getContainer\0QMap<int,FolderContent>*\0"
    "moveContent\0_toIndex\0_fromIndex\0"
    "updateRanks\0getRank\0setRank\0"
    "getFolderContents\0QList<FolderContent>\0"
    "getPChosen\0setPChosen\0hasChosen\0"
    "moveChosen2Next\0moveChosen2Last\0"
    "getPointedContent\0isEmptyFolder\0"
    "getNextRankByPlayOrder\0PlayOrder\0"
    "playOrder\0getRankedFilePaths"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Folder[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  149,    2, 0x0a /* Public */,
       3,    1,  152,    2, 0x0a /* Public */,
       4,    0,  155,    2, 0x0a /* Public */,
       6,    0,  156,    2, 0x0a /* Public */,
       7,    0,  157,    2, 0x0a /* Public */,
       8,    0,  158,    2, 0x0a /* Public */,
       9,    0,  159,    2, 0x0a /* Public */,
      10,    1,  160,    2, 0x0a /* Public */,
      11,    1,  163,    2, 0x0a /* Public */,
      13,    1,  166,    2, 0x0a /* Public */,
      14,    0,  169,    2, 0x0a /* Public */,
      15,    1,  170,    2, 0x0a /* Public */,
      17,    0,  173,    2, 0x0a /* Public */,
      19,    2,  174,    2, 0x0a /* Public */,
      22,    1,  179,    2, 0x0a /* Public */,
      23,    0,  182,    2, 0x0a /* Public */,
      24,    1,  183,    2, 0x0a /* Public */,
      25,    0,  186,    2, 0x0a /* Public */,
      27,    0,  187,    2, 0x0a /* Public */,
      28,    1,  188,    2, 0x0a /* Public */,
      29,    0,  191,    2, 0x0a /* Public */,
      30,    0,  192,    2, 0x0a /* Public */,
      31,    0,  193,    2, 0x0a /* Public */,
      32,    0,  194,    2, 0x0a /* Public */,
      33,    0,  195,    2, 0x0a /* Public */,
      34,    1,  196,    2, 0x0a /* Public */,
      37,    0,  199,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::QString, QMetaType::Int,    2,
    0x80000000 | 5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool, QMetaType::QString,    2,
    QMetaType::Void, 0x80000000 | 12,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString,   16,
    0x80000000 | 18,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   20,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   16,
    0x80000000 | 26,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Int, 0x80000000 | 35,   36,
    QMetaType::QStringList,

       0        // eod
};

void Folder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Folder *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->getFolderContent((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 1: { QString _r = _t->getFileName((*reinterpret_cast< const int(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 2: { QList<QString> _r = _t->getFileNames();
            if (_a[0]) *reinterpret_cast< QList<QString>*>(_a[0]) = std::move(_r); }  break;
        case 3: _t->makeContainerEmpty(); break;
        case 4: _t->makeFileNamesEmpty(); break;
        case 5: _t->makePChosenEmpty(); break;
        case 6: _t->makeEmpty(); break;
        case 7: { bool _r = _t->hasFile((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: _t->addAndSetRankContent((*reinterpret_cast< FolderContent(*)>(_a[1]))); break;
        case 9: _t->removeContent((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 10: { QString _r = _t->getFolderName();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 11: _t->setFolderName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 12: { QMap<int,FolderContent>* _r = _t->getContainer();
            if (_a[0]) *reinterpret_cast< QMap<int,FolderContent>**>(_a[0]) = std::move(_r); }  break;
        case 13: _t->moveContent((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 14: _t->updateRanks((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 15: { int _r = _t->getRank();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->setRank((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: { QList<FolderContent> _r = _t->getFolderContents();
            if (_a[0]) *reinterpret_cast< QList<FolderContent>*>(_a[0]) = std::move(_r); }  break;
        case 18: { int _r = _t->getPChosen();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 19: _t->setPChosen((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: { bool _r = _t->hasChosen();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 21: _t->moveChosen2Next(); break;
        case 22: _t->moveChosen2Last(); break;
        case 23: _t->getPointedContent(); break;
        case 24: { bool _r = _t->isEmptyFolder();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 25: { int _r = _t->getNextRankByPlayOrder((*reinterpret_cast< const PlayOrder(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 26: { QStringList _r = _t->getRankedFilePaths();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Folder::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Folder.data,
    qt_meta_data_Folder,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Folder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Folder::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Folder.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Folder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
