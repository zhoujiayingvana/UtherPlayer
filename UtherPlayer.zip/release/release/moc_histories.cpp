/****************************************************************************
** Meta object code from reading C++ file 'histories.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../util/histories.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'histories.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Histories_t {
    QByteArrayData data[43];
    char stringdata0[588];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Histories_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Histories_t qt_meta_stringdata_Histories = {
    {
QT_MOC_LITERAL(0, 0, 9), // "Histories"
QT_MOC_LITERAL(1, 10, 12), // "makeMapEmpty"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 9), // "makeEmpty"
QT_MOC_LITERAL(4, 34, 14), // "checkMaxNumber"
QT_MOC_LITERAL(5, 49, 16), // "hasRemainedPlace"
QT_MOC_LITERAL(6, 66, 10), // "addContent"
QT_MOC_LITERAL(7, 77, 9), // "_fileName"
QT_MOC_LITERAL(8, 87, 9), // "_filePath"
QT_MOC_LITERAL(9, 97, 8), // "_isLocal"
QT_MOC_LITERAL(10, 106, 7), // "int64_t"
QT_MOC_LITERAL(11, 114, 20), // "_progressMillisecond"
QT_MOC_LITERAL(12, 135, 17), // "HistoricalContent"
QT_MOC_LITERAL(13, 153, 13), // "removeContent"
QT_MOC_LITERAL(14, 167, 20), // "getHistoricalContent"
QT_MOC_LITERAL(15, 188, 11), // "getUserName"
QT_MOC_LITERAL(16, 200, 11), // "setUserName"
QT_MOC_LITERAL(17, 212, 5), // "value"
QT_MOC_LITERAL(18, 218, 10), // "getMaxSize"
QT_MOC_LITERAL(19, 229, 14), // "getAllContents"
QT_MOC_LITERAL(20, 244, 24), // "QList<HistoricalContent>"
QT_MOC_LITERAL(21, 269, 9), // "startInit"
QT_MOC_LITERAL(22, 279, 10), // "startClose"
QT_MOC_LITERAL(23, 290, 11), // "moveContent"
QT_MOC_LITERAL(24, 302, 15), // "_toContentIndex"
QT_MOC_LITERAL(25, 318, 17), // "_fromContentIndex"
QT_MOC_LITERAL(26, 336, 10), // "getPChosen"
QT_MOC_LITERAL(27, 347, 10), // "setPChosen"
QT_MOC_LITERAL(28, 358, 9), // "hasChosen"
QT_MOC_LITERAL(29, 368, 15), // "moveChosen2Next"
QT_MOC_LITERAL(30, 384, 15), // "moveChosen2Last"
QT_MOC_LITERAL(31, 400, 27), // "getPointedHistoricalContent"
QT_MOC_LITERAL(32, 428, 22), // "getPointedMediaContent"
QT_MOC_LITERAL(33, 451, 14), // "QMediaContent*"
QT_MOC_LITERAL(34, 466, 7), // "isEmpty"
QT_MOC_LITERAL(35, 474, 22), // "getNextRankByPlayOrder"
QT_MOC_LITERAL(36, 497, 9), // "PlayOrder"
QT_MOC_LITERAL(37, 507, 9), // "playOrder"
QT_MOC_LITERAL(38, 517, 11), // "getAllPaths"
QT_MOC_LITERAL(39, 529, 10), // "move2First"
QT_MOC_LITERAL(40, 540, 17), // "getRankByFilePath"
QT_MOC_LITERAL(41, 558, 10), // "get4Client"
QT_MOC_LITERAL(42, 569, 18) // "QList<QStringList>"

    },
    "Histories\0makeMapEmpty\0\0makeEmpty\0"
    "checkMaxNumber\0hasRemainedPlace\0"
    "addContent\0_fileName\0_filePath\0_isLocal\0"
    "int64_t\0_progressMillisecond\0"
    "HistoricalContent\0removeContent\0"
    "getHistoricalContent\0getUserName\0"
    "setUserName\0value\0getMaxSize\0"
    "getAllContents\0QList<HistoricalContent>\0"
    "startInit\0startClose\0moveContent\0"
    "_toContentIndex\0_fromContentIndex\0"
    "getPChosen\0setPChosen\0hasChosen\0"
    "moveChosen2Next\0moveChosen2Last\0"
    "getPointedHistoricalContent\0"
    "getPointedMediaContent\0QMediaContent*\0"
    "isEmpty\0getNextRankByPlayOrder\0PlayOrder\0"
    "playOrder\0getAllPaths\0move2First\0"
    "getRankByFilePath\0get4Client\0"
    "QList<QStringList>"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Histories[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  154,    2, 0x0a /* Public */,
       3,    0,  155,    2, 0x0a /* Public */,
       4,    0,  156,    2, 0x0a /* Public */,
       5,    0,  157,    2, 0x0a /* Public */,
       6,    4,  158,    2, 0x0a /* Public */,
       6,    1,  167,    2, 0x0a /* Public */,
      13,    1,  170,    2, 0x0a /* Public */,
      14,    1,  173,    2, 0x0a /* Public */,
      15,    0,  176,    2, 0x0a /* Public */,
      16,    1,  177,    2, 0x0a /* Public */,
      18,    0,  180,    2, 0x0a /* Public */,
      19,    0,  181,    2, 0x0a /* Public */,
      21,    0,  182,    2, 0x0a /* Public */,
      22,    0,  183,    2, 0x0a /* Public */,
      23,    2,  184,    2, 0x0a /* Public */,
      26,    0,  189,    2, 0x0a /* Public */,
      27,    1,  190,    2, 0x0a /* Public */,
      28,    0,  193,    2, 0x0a /* Public */,
      29,    0,  194,    2, 0x0a /* Public */,
      30,    0,  195,    2, 0x0a /* Public */,
      31,    0,  196,    2, 0x0a /* Public */,
      32,    0,  197,    2, 0x0a /* Public */,
      34,    0,  198,    2, 0x0a /* Public */,
      35,    1,  199,    2, 0x0a /* Public */,
      38,    0,  202,    2, 0x0a /* Public */,
      39,    1,  203,    2, 0x0a /* Public */,
      40,    1,  206,    2, 0x0a /* Public */,
      41,    0,  209,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Bool, 0x80000000 | 10,    7,    8,    9,   11,
    QMetaType::Void, 0x80000000 | 12,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Int,
    0x80000000 | 20,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   24,   25,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int,   17,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 33,
    QMetaType::Bool,
    QMetaType::Int, 0x80000000 | 36,   37,
    QMetaType::QStringList,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Int, QMetaType::QString,    8,
    0x80000000 | 42,

       0        // eod
};

void Histories::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Histories *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->makeMapEmpty(); break;
        case 1: _t->makeEmpty(); break;
        case 2: _t->checkMaxNumber(); break;
        case 3: { bool _r = _t->hasRemainedPlace();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 4: _t->addContent((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const bool(*)>(_a[3])),(*reinterpret_cast< const int64_t(*)>(_a[4]))); break;
        case 5: _t->addContent((*reinterpret_cast< const HistoricalContent(*)>(_a[1]))); break;
        case 6: _t->removeContent((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 7: _t->getHistoricalContent((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 8: { QString _r = _t->getUserName();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 9: _t->setUserName((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: { int _r = _t->getMaxSize();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 11: { QList<HistoricalContent> _r = _t->getAllContents();
            if (_a[0]) *reinterpret_cast< QList<HistoricalContent>*>(_a[0]) = std::move(_r); }  break;
        case 12: _t->startInit(); break;
        case 13: _t->startClose(); break;
        case 14: _t->moveContent((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2]))); break;
        case 15: { int _r = _t->getPChosen();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 16: _t->setPChosen((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: { bool _r = _t->hasChosen();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 18: _t->moveChosen2Next(); break;
        case 19: _t->moveChosen2Last(); break;
        case 20: _t->getPointedHistoricalContent(); break;
        case 21: { QMediaContent* _r = _t->getPointedMediaContent();
            if (_a[0]) *reinterpret_cast< QMediaContent**>(_a[0]) = std::move(_r); }  break;
        case 22: { bool _r = _t->isEmpty();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 23: { int _r = _t->getNextRankByPlayOrder((*reinterpret_cast< const PlayOrder(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 24: { QStringList _r = _t->getAllPaths();
            if (_a[0]) *reinterpret_cast< QStringList*>(_a[0]) = std::move(_r); }  break;
        case 25: _t->move2First((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 26: { int _r = _t->getRankByFilePath((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = std::move(_r); }  break;
        case 27: { QList<QStringList> _r = _t->get4Client();
            if (_a[0]) *reinterpret_cast< QList<QStringList>*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Histories::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_Histories.data,
    qt_meta_data_Histories,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Histories::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Histories::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Histories.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int Histories::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 28;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
