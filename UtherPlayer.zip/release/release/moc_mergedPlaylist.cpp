/****************************************************************************
** Meta object code from reading C++ file 'mergedPlaylist.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../mergedPlaylist.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mergedPlaylist.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_mergedPlaylist_t {
    QByteArrayData data[32];
    char stringdata0[563];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_mergedPlaylist_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_mergedPlaylist_t qt_meta_stringdata_mergedPlaylist = {
    {
QT_MOC_LITERAL(0, 0, 14), // "mergedPlaylist"
QT_MOC_LITERAL(1, 15, 13), // "sendDirSignal"
QT_MOC_LITERAL(2, 29, 0), // ""
QT_MOC_LITERAL(3, 30, 4), // "QDir"
QT_MOC_LITERAL(4, 35, 20), // "givingTempSNAndFiles"
QT_MOC_LITERAL(5, 56, 14), // "QList<QString>"
QT_MOC_LITERAL(6, 71, 21), // "showChangedListSignal"
QT_MOC_LITERAL(7, 93, 14), // "givingListName"
QT_MOC_LITERAL(8, 108, 28), // "hideContentsExceptThisSignal"
QT_MOC_LITERAL(9, 137, 17), // "hideContentSignal"
QT_MOC_LITERAL(10, 155, 22), // "allowDragAndMenuSignal"
QT_MOC_LITERAL(11, 178, 10), // "deleteList"
QT_MOC_LITERAL(12, 189, 14), // "sendFolderName"
QT_MOC_LITERAL(13, 204, 19), // "sendAddFileToFolder"
QT_MOC_LITERAL(14, 224, 12), // "sendPlayInfo"
QT_MOC_LITERAL(15, 237, 8), // "PlayArea"
QT_MOC_LITERAL(16, 246, 13), // "removeContent"
QT_MOC_LITERAL(17, 260, 25), // "showOrHideListContentSlot"
QT_MOC_LITERAL(18, 286, 21), // "hideOtherContentsSlot"
QT_MOC_LITERAL(19, 308, 14), // "recevingTempSN"
QT_MOC_LITERAL(20, 323, 21), // "changeFilesInListSlot"
QT_MOC_LITERAL(21, 345, 9), // "currentSN"
QT_MOC_LITERAL(22, 355, 16), // "temp_filesInList"
QT_MOC_LITERAL(23, 372, 26), // "leftBarListFilesChangeSlot"
QT_MOC_LITERAL(24, 399, 15), // "wantingNameSlot"
QT_MOC_LITERAL(25, 415, 15), // "hideContentSlot"
QT_MOC_LITERAL(26, 431, 26), // "deleteListRequestAnswering"
QT_MOC_LITERAL(27, 458, 18), // "sendTempFolderName"
QT_MOC_LITERAL(28, 477, 24), // "temp_addFileToFolderSlot"
QT_MOC_LITERAL(29, 502, 15), // "getTempPlayInfo"
QT_MOC_LITERAL(30, 518, 22), // "temp_removeContentSlot"
QT_MOC_LITERAL(31, 541, 21) // "deleteFilesInListSlot"

    },
    "mergedPlaylist\0sendDirSignal\0\0QDir\0"
    "givingTempSNAndFiles\0QList<QString>\0"
    "showChangedListSignal\0givingListName\0"
    "hideContentsExceptThisSignal\0"
    "hideContentSignal\0allowDragAndMenuSignal\0"
    "deleteList\0sendFolderName\0sendAddFileToFolder\0"
    "sendPlayInfo\0PlayArea\0removeContent\0"
    "showOrHideListContentSlot\0"
    "hideOtherContentsSlot\0recevingTempSN\0"
    "changeFilesInListSlot\0currentSN\0"
    "temp_filesInList\0leftBarListFilesChangeSlot\0"
    "wantingNameSlot\0hideContentSlot\0"
    "deleteListRequestAnswering\0"
    "sendTempFolderName\0temp_addFileToFolderSlot\0"
    "getTempPlayInfo\0temp_removeContentSlot\0"
    "deleteFilesInListSlot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_mergedPlaylist[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  139,    2, 0x06 /* Public */,
       4,    2,  142,    2, 0x06 /* Public */,
       6,    2,  147,    2, 0x06 /* Public */,
       7,    1,  152,    2, 0x06 /* Public */,
       8,    1,  155,    2, 0x06 /* Public */,
       9,    0,  158,    2, 0x06 /* Public */,
      10,    0,  159,    2, 0x06 /* Public */,
      11,    1,  160,    2, 0x06 /* Public */,
      12,    2,  163,    2, 0x06 /* Public */,
      13,    4,  168,    2, 0x06 /* Public */,
      14,    3,  177,    2, 0x06 /* Public */,
      16,    2,  184,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      17,    1,  189,    2, 0x0a /* Public */,
      18,    1,  192,    2, 0x0a /* Public */,
      19,    1,  195,    2, 0x0a /* Public */,
      20,    2,  198,    2, 0x0a /* Public */,
      23,    2,  203,    2, 0x0a /* Public */,
      24,    1,  208,    2, 0x0a /* Public */,
      25,    0,  211,    2, 0x0a /* Public */,
      26,    0,  212,    2, 0x0a /* Public */,
      27,    2,  213,    2, 0x0a /* Public */,
      28,    4,  218,    2, 0x0a /* Public */,
      29,    3,  227,    2, 0x0a /* Public */,
      30,    2,  234,    2, 0x0a /* Public */,
      31,    2,  239,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 5,    2,    2,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 5,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 15, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 5,   21,   22,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 5,    2,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::Bool,    2,    2,    2,    2,
    QMetaType::Void, 0x80000000 | 15, QMetaType::Int, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,    2,    2,
    QMetaType::Void, QMetaType::Int, 0x80000000 | 5,    2,    2,

       0        // eod
};

void mergedPlaylist::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<mergedPlaylist *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendDirSignal((*reinterpret_cast< QDir(*)>(_a[1]))); break;
        case 1: _t->givingTempSNAndFiles((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QList<QString>(*)>(_a[2]))); break;
        case 2: _t->showChangedListSignal((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QList<QString>(*)>(_a[2]))); break;
        case 3: _t->givingListName((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->hideContentsExceptThisSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->hideContentSignal(); break;
        case 6: _t->allowDragAndMenuSignal(); break;
        case 7: _t->deleteList((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->sendFolderName((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 9: _t->sendAddFileToFolder((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const bool(*)>(_a[4]))); break;
        case 10: _t->sendPlayInfo((*reinterpret_cast< const PlayArea(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 11: _t->removeContent((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 12: _t->showOrHideListContentSlot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->hideOtherContentsSlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->recevingTempSN((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->changeFilesInListSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QList<QString>(*)>(_a[2]))); break;
        case 16: _t->leftBarListFilesChangeSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QList<QString>(*)>(_a[2]))); break;
        case 17: _t->wantingNameSlot((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->hideContentSlot(); break;
        case 19: _t->deleteListRequestAnswering(); break;
        case 20: _t->sendTempFolderName((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 21: _t->temp_addFileToFolderSlot((*reinterpret_cast< const int(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< const QString(*)>(_a[3])),(*reinterpret_cast< const bool(*)>(_a[4]))); break;
        case 22: _t->getTempPlayInfo((*reinterpret_cast< const PlayArea(*)>(_a[1])),(*reinterpret_cast< const int(*)>(_a[2])),(*reinterpret_cast< const int(*)>(_a[3]))); break;
        case 23: _t->temp_removeContentSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 24: _t->deleteFilesInListSlot((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QList<QString>(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QString> >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (mergedPlaylist::*)(QDir );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::sendDirSignal)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int , QList<QString> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::givingTempSNAndFiles)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int , QList<QString> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::showChangedListSignal)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::givingListName)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::hideContentsExceptThisSignal)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::hideContentSignal)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::allowDragAndMenuSignal)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::deleteList)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::sendFolderName)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(const int & , const QString & , const QString & , const bool & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::sendAddFileToFolder)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(const PlayArea & , const int & , const int & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::sendPlayInfo)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (mergedPlaylist::*)(int , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&mergedPlaylist::removeContent)) {
                *result = 11;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject mergedPlaylist::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_mergedPlaylist.data,
    qt_meta_data_mergedPlaylist,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *mergedPlaylist::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *mergedPlaylist::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_mergedPlaylist.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int mergedPlaylist::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}

// SIGNAL 0
void mergedPlaylist::sendDirSignal(QDir _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void mergedPlaylist::givingTempSNAndFiles(int _t1, QList<QString> _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void mergedPlaylist::showChangedListSignal(int _t1, QList<QString> _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void mergedPlaylist::givingListName(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void mergedPlaylist::hideContentsExceptThisSignal(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void mergedPlaylist::hideContentSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void mergedPlaylist::allowDragAndMenuSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void mergedPlaylist::deleteList(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void mergedPlaylist::sendFolderName(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void mergedPlaylist::sendAddFileToFolder(const int & _t1, const QString & _t2, const QString & _t3, const bool & _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void mergedPlaylist::sendPlayInfo(const PlayArea & _t1, const int & _t2, const int & _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void mergedPlaylist::removeContent(int _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
